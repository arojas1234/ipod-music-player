// Create your global variables below:
var tracklist = ["Moscow Mule", "Después de la Playa", "Me Porto Bonito", "Tití Me Preguntó", "Un Ratito", "Yo No Soy Celoso", 
"Tarot", "Neverita", "La Corriente", "Efecto"];
var volLevels = [];

var slider = document.getElementById("myRange");

let timer
let bool

if (bool) {
	clearInterval(timer);
	timer = setInterval(addTime, 1000);
}

function init() {
	// Your code goes here
	var i;
	for (var i=0; i<6; i++) {
		volLevels[i] = document.getElementById("vl"+i);
	}
	volLevels[0].style.backgroundColor = "#9f5cc4";
	volLevels[1].style.backgroundColor = "#9f5cc4";
	volLevels[2].style.backgroundColor = "#9f5cc4";
};

function volUp() {
	// Your code goes here
	for (var i = 0; i < 6; i++) {
		if (volLevels[i].style.backgroundColor == "") {
			volLevels[i].style.backgroundColor = "#9f5cc4";
			return;
		}
	}
}

function volDown() {
	// Your code goes here
	for (var i = 0; i < 6; i++) {
		if (volLevels[5-i].style.backgroundColor != "") {
			volLevels[5-i].style.backgroundColor = "";
			return;
		}
	}
}

function addTime(){
	slider.stepUp();
	if (slider.value >= 180){
		clearInterval(timer);
		nextSong()
		switchPlay()
		switchPlay()
	}
	document.getElementById("time-elapsed").innerHTML = secondsToMs(slider.value);
}

function switchPlay() {
	// Your code goes here
	if (document.getElementById("play-pause").innerHTML == "play_arrow") {
		document.getElementById("play-pause").innerHTML = "pause";
		document.getElementById("time-elapsed").innerHTML = secondsToMs(slider.value);
		timer = setInterval(addTime, 1000);
		bool = true;
	}
	else {
		document.getElementById("play-pause").innerHTML = "play_arrow";
		clearInterval(timer);
		bool = false;
	}
}

function nextSong() {
	// Your code goes here
	slider.value = 0
	document.getElementById("time-elapsed").innerHTML = "0:00";

	if (document.getElementById("player-song-name").innerHTML == tracklist[9]) {
		document.getElementById("player-song-name").innerHTML = tracklist[0];
		return;
	}

	for (var i = 0; i < 9; i++) {
		if (document.getElementById("player-song-name").innerHTML == tracklist[i]) {
			document.getElementById("player-song-name").innerHTML = tracklist[i+1];
			return;
		}
	}
}

function prevSong() {
	// Your code goes here
	slider.value = 0
	document.getElementById("time-elapsed").innerHTML = "0:00";

	if (document.getElementById("player-song-name").innerHTML == tracklist[0]) {
		document.getElementById("player-song-name").innerHTML = tracklist[9];
		return;
	}

	for (var i = 9; i >= 0; i--) {
		if (document.getElementById("player-song-name").innerHTML == tracklist[i]) {
			document.getElementById("player-song-name").innerHTML = tracklist[i-1];
			return;
		}
	}
}

function secondsToMs(d) {
    d = Number(d);

    var min = Math.floor(d / 60);
    var sec = Math.floor(d % 60);

    return `0${min}`.slice(-1) + ":" + `00${sec}`.slice(-2);
}

init();